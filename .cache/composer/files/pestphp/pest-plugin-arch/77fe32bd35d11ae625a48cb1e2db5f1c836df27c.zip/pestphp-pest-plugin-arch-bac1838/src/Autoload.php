<?php

declare(strict_types=1);

use Pest\Arch\Concerns\Architectable;
use Pest\Plugin;

Plugin::uses(Architectable::class);
