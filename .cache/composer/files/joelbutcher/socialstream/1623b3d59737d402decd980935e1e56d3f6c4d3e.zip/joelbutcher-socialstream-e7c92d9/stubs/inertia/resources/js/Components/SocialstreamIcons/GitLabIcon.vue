<template>
    <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12,23.1l4.4-13.6H7.6L12,23.1z" fill="#E24329"/>
        <path d="M12,23.1L7.6,9.4H1.4L12,23.1z" fill="#FC6D26"/>
        <path d="M1.4,9.4L0,13.6c-0.1,0.4,0,0.8,0.3,1L12,23.1L1.4,9.4z" fill="#FCA326"/>
        <path d="M1.4,9.4h6.2L4.9,1.3C4.8,0.8,4.2,0.8,4,1.3L1.4,9.4z" fill="#E24329"/>
        <path d="M12,23.1l4.4-13.6h6.2L12,23.1z" fill="#FC6D26"/>
        <path d="M22.6,9.4l1.3,4.1c0.1,0.4,0,0.8-0.3,1L12,23.1L22.6,9.4z" fill="#FCA326"/>
        <path d="M22.6,9.4h-6.2l2.7-8.2c0.1-0.4,0.7-0.4,0.9,0L22.6,9.4z" fill="#E24329"/>
    </svg>
</template>

<script>
    export default {

    }
</script>
