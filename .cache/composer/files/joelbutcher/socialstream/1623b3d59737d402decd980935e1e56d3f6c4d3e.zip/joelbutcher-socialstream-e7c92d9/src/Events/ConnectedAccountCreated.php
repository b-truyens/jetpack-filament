<?php

namespace JoelButcher\Socialstream\Events;

class ConnectedAccountCreated extends ConnectedAccountEvent
{
    //
}
