<?php

namespace JoelButcher\Socialstream\Events;

class ConnectedAccountUpdated extends ConnectedAccountEvent
{
    //
}
