<?php

namespace JoelButcher\Socialstream\Events;

class ConnectedAccountDeleted extends ConnectedAccountEvent
{
    //
}
